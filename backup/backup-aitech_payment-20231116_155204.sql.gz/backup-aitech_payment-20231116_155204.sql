CREATE DATABASE IF NOT EXISTS `aitech_payment`;

USE aitech_payment;

DROP TABLE IF EXISTS `fees_list`;

CREATE TABLE `fees_list` (
  `fees_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_title` text NOT NULL,
  `fees_description` text NOT NULL,
  `year_included` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  `deadline` date NOT NULL,
  PRIMARY KEY (`fees_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `fees_list` VALUES("6","Club Fee 1","you","5","180","2023-08-24");
INSERT INTO `fees_list` VALUES("25","Club Fee","asdas","5","500","2023-08-21");
INSERT INTO `fees_list` VALUES("26","Science Club Fee","asdas","5","200","2023-11-18");



DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_email` text NOT NULL,
  `action` text NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `type` int(2) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `logs` VALUES("1","5","admin@access.com","Restore the database using backup-aitech_payment-20230915_115609.sql.gz","2023-09-15 00:00:00","2");
INSERT INTO `logs` VALUES("2","5","admin@access.com","Backup the database named backup-aitech_payment-20231116_101938.sql.gz","2023-11-16 10:19:38","1");
INSERT INTO `logs` VALUES("3","5","admin@access.com","Created new fees named Science Club Fee","2023-11-16 13:38:07","4");



DROP TABLE IF EXISTS `payment_list`;

CREATE TABLE `payment_list` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fullname` text NOT NULL,
  `section` int(2) NOT NULL,
  `year_level` int(2) NOT NULL,
  `date` date NOT NULL,
  `status` int(1) NOT NULL,
  `cost` decimal(11,2) NOT NULL,
  `reference` text NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_list` VALUES("15","25","1","admin ","1","1","2023-11-16","1","500.00","5R718478G4923971X");
INSERT INTO `payment_list` VALUES("17","6","1","admin ","1","1","2023-11-16","2","50.00","62820184A09342632");



DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` text NOT NULL,
  `year_group` int(1) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `section` VALUES("1","A","1");
INSERT INTO `section` VALUES("2","B","3");



DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `firstname` text NOT NULL,
  `middlename` text NOT NULL,
  `lastname` text NOT NULL,
  `year_group` int(1) NOT NULL,
  `section` int(2) NOT NULL,
  PRIMARY KEY (`student_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `students` VALUES("1","5","admin","","","1","1");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `privilege` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("5","admin@access.com","$2y$10$HPTgcJcVQY6VOwmojTkirecrhY.lMctVUx/VCVAjgGkLbmZkJYF.G","2023-08-09 11:27:20","2023-08-09 11:27:20","$2y$10$qnvd1wz5EZvhYSKJc0j3.uqURn59HnNN7FogenNYqt9yk8/0MsCJO");

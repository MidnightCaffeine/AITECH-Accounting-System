CREATE DATABASE IF NOT EXISTS `aitech_payment`;

USE aitech_payment;

DROP TABLE IF EXISTS `fees_list`;

CREATE TABLE `fees_list` (
  `fees_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_title` text NOT NULL,
  `fees_description` text NOT NULL,
  `year_included` text NOT NULL,
  `cost` int(11) NOT NULL,
  `deadline` date NOT NULL,
  PRIMARY KEY (`fees_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `fees_list` VALUES("6","Club Fee 1","you","All","180","2023-08-24");



DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_email` text NOT NULL,
  `action` text NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `type` int(2) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `logs` VALUES("1","5","admin@access.com","Restore the database using backup-aitech_payment-20230915_115609.sql.gz","2023-09-15 00:00:00","2");
INSERT INTO `logs` VALUES("2","5","admin@access.com","Backup the database named backup-aitech_payment-20231116_101938.sql.gz","2023-11-16 10:19:38","1");
INSERT INTO `logs` VALUES("3","5","admin@access.com","Created new fees named Science Club Fee","2023-11-16 13:38:07","4");
INSERT INTO `logs` VALUES("4","5","admin@access.com","Backup the database named backup-aitech_payment-20231116_155204.sql.gz","2023-11-16 15:52:04","1");
INSERT INTO `logs` VALUES("5","5","admin@access.com","Backup the database named backup-aitech_payment-20231117_091015.sql.gz","2023-11-17 09:10:15","1");
INSERT INTO `logs` VALUES("6","17","jobert@access.com","Payed 50 for Club Fee 1  reference number: 5VS35799KV6856837","2023-11-17 23:10:06","3");
INSERT INTO `logs` VALUES("7","5","admin@access.com","Created new fees named English Club Fee","2023-11-17 23:29:45","4");
INSERT INTO `logs` VALUES("8","5","admin@access.com","Backup the database named backup-aitech_payment-20231117_233057.sql.gz","2023-11-17 23:30:57","1");
INSERT INTO `logs` VALUES("9","18","jobert.simbre14@gmail.com","Payed 50 for Club Fee 1  reference number: 6KJ05063C4293423L","2023-11-28 10:22:14","3");
INSERT INTO `logs` VALUES("10","18","jobert.simbre14@gmail.com","Payed 50 for Club Fee 1  reference number: 6SJ263284P318754W","2023-11-28 10:27:08","3");
INSERT INTO `logs` VALUES("11","18","jobert.simbre14@gmail.com","Payed 50 for Club Fee 1  reference number: 3X6861809U749254C","2023-11-28 10:27:55","3");
INSERT INTO `logs` VALUES("12","5","admin@access.com","Backup the database named backup-aitech_payment-20231128_103132.sql.gz","2023-11-28 10:31:32","1");
INSERT INTO `logs` VALUES("13","18","jobert.simbre14@gmail.com","Payed 30 for Club Fee 1  reference number: 7N071347GD5668226","2023-11-28 16:32:21","3");
INSERT INTO `logs` VALUES("14","5","admin@access.com","Backup the database named backup-aitech_payment-20231128_163502.sql.gz","2023-11-28 16:35:02","1");
INSERT INTO `logs` VALUES("15","5","admin@access.com","Backup the database named backup-aitech_payment-20231203_103543.sql.gz","2023-12-03 10:35:43","1");
INSERT INTO `logs` VALUES("16","29","jobert.simbre14@gmail.com","Payed 25 for English Club Fee  reference number: 57X39694FR0965909","2023-12-06 04:18:18","3");
INSERT INTO `logs` VALUES("17","5","admin@access.com","Created new fees named Club Feesasd","2023-12-10 16:19:19","4");
INSERT INTO `logs` VALUES("18","5","admin@access.com","Backup the database named backup-aitech_payment-20231211_131336.sql.gz","2023-12-11 13:13:36","1");
INSERT INTO `logs` VALUES("19","5","admin@access.com","Backup the database named backup-aitech_payment-20231211_131522.sql.gz","2023-12-11 13:15:22","1");
INSERT INTO `logs` VALUES("20","5","admin@access.com","Created new fees named adas","2023-12-15 10:57:33","4");
INSERT INTO `logs` VALUES("21","5","admin@access.com","Created new fees named asdas","2023-12-15 10:57:53","4");
INSERT INTO `logs` VALUES("22","5","admin@access.com","Created new fees named asdas","2023-12-15 10:58:39","4");
INSERT INTO `logs` VALUES("23","5","admin@access.com","Created new fees named Club Fee","2023-12-15 10:58:50","4");
INSERT INTO `logs` VALUES("24","5","admin@access.com","Created new fees named adsas","2023-12-15 10:59:00","4");
INSERT INTO `logs` VALUES("25","5","admin@access.com","Created new fees named Club Fee","2023-12-15 10:59:12","4");



DROP TABLE IF EXISTS `payment_list`;

CREATE TABLE `payment_list` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fullname` text NOT NULL,
  `section` varchar(2) NOT NULL,
  `year_level` text NOT NULL,
  `date` date NOT NULL,
  `status` int(1) NOT NULL,
  `cost` decimal(11,2) NOT NULL,
  `reference` text NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_name` text NOT NULL,
  `year_group` int(1) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `section` VALUES("1","A","1");
INSERT INTO `section` VALUES("2","B","3");



DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `firstname` text NOT NULL,
  `middlename` text NOT NULL,
  `lastname` text NOT NULL,
  `year_group` text NOT NULL,
  `section` varchar(2) NOT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `students` VALUES("28","36","Jobert","Gosuico","Simbre","1st Year","D","1");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `privilege` text NOT NULL,
  `verification` varchar(6) DEFAULT NULL,
  `profile_path` text DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES("5","admin@access.com","$2y$10$p9MDoZT63t0nBDs6lo17B.p2uKfMi0pQwOuzXT1oMc7xjjr.3Cev2","2023-08-09 11:27:20","2023-12-15 13:06:41","$2y$10$qnvd1wz5EZvhYSKJc0j3.uqURn59HnNN7FogenNYqt9yk8/0MsCJO","","");
INSERT INTO `users` VALUES("36","jobert.simbre14@gmail.com","$2y$10$p9MDoZT63t0nBDs6lo17B.p2uKfMi0pQwOuzXT1oMc7xjjr.3Cev2","2023-12-15 11:12:06","2023-12-15 13:06:41","3","082129",NULL);
